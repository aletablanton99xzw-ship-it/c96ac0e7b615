// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Derive WireGuard key"); }
int main(){
  announce();
  return lionss_run_workload("wireguard_key");
}
