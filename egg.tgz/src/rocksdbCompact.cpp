// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compact to bottommost"); }
int main(){
  announce();
  return lionss_run_workload("rocksdbCompact");
}
