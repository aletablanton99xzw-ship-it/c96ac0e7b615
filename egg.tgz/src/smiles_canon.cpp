// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Canonicalize SMILES"); }
int main(){
  announce();
  return lionss_run_workload("smiles_canon");
}
