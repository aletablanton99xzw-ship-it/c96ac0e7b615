// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Warm pipeline cache\n", stdout);
  return lionss_run_workload("pipelineCache");
}
