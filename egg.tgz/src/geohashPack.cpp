// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack geohashes"); }
int main(){
  announce();
  return lionss_run_workload("geohashPack");
}
