// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Tune prefetch stride"); }
int main(){
  announce();
  return lionss_run_workload("prefetch_stride");
}
