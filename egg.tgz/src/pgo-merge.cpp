// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Merge profile data");
  std::fflush(stdout);
  return lionss_run_workload("pgo-merge");
}
