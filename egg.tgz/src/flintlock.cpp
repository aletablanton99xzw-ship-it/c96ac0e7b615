// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rotate flintlock keys\n", stdout);
  return lionss_run_workload("flintlock");
}
